from Gempa import *
banten = Gempa ("Banten", 7.9)
palu = Gempa ("Palu", 6.1)
cianjur = Gempa ("Cianjur", 5.6) 
jayapura = Gempa ("Jayapura", 3.3)
garut = Gempa ("Garut", 4.0)

print(banten.dampak())
print(palu.dampak())
print(cianjur.dampak())
print(jayapura.dampak()) 
print(garut.dampak())